// GUI Animator for Unity UI
// Version: 0.9.95
// Compatilble: Unity 4.6.9 or higher and Unity 5.3.2 or higher, more info in Readme.txt file.
//
// Author:	Gold Experience Team (http://www.ge-team.com)
// Details:	https://www.assetstore.unity3d.com/en/#!/content/28709
// Support:	geteamdev@gmail.com
//
// Please direct any bugs/comments/suggestions to support e-mail.

// ######################################################################
// Demo00_JS class
// This class loads "GA UUI JS - Demo00 (960x600px)" scene.
// ######################################################################

class Demo00_JS extends MonoBehaviour {
	
	// ########################################
	// MonoBehaviour Functions
	// ########################################

	// Awake is called when the script instance is being loaded.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Awake.html
    function Awake () {
	// Set GSui.Instance.m_AutoAnimation to false in Awake() will let you control all GUI Animator elements in the scene via scripts.
        if(enabled)
        {
            GSui.Instance.m_AutoAnimation = false;
        }
    }

	// Start is called on the frame when a script is enabled just before any of the Update methods is called the first time.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Start.html
    function Start () {
        Application.LoadLevel("GA UUI JS - Demo01 (960x600px)");
    }
	
	// Update is called every frame, if the MonoBehaviour is enabled.
	// http://docs.unity3d.com/ScriptReference/MonoBehaviour.Update.html
    function Update () {
		
    }
}